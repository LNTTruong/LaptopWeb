- install python
- install Mysql

- chạy câu lệnh: py -m venv env
- active môi trường: <tùy thuộc vào hệ điều hành>
- install Django: pip install django
- tải các thư viện: pip install -r requirements.txt
- tạo database, cấu hình lại file core/settings.py ở mục database
- chạy câu lệnh: py manage.py runserver để vào website

- Thêm dữ liệu vào database:
